import React, { useState } from 'react'
import axios from "axios"
import "./index.css"
import View from './View'

function Search() {
  const [value , setValue] = useState("")
  const [data , setData] = useState([])

 async function handleViews(){
   let res = await axios.get(`http://localhost:4000/api/v1/search?search=${value}`)
   setData(res.data);
   console.log(res.data);
   
  }

  function handleClick(e){
    e.preventDefault()
    handleViews()
  }
  return (
    <div>
        <h1 id='heading'>SEARCH ENGINE</h1>
        <form id='form' action=''>
        <input id='input' value={value} onChange={(e) =>setValue(e.target.value)} type='text'/>
        <button id='btn' onClick={(e) =>handleClick(e)} type='button'>Search</button>
        </form>

        {
        data.map((i,k)=> <View key={k} title={i.title} description={i.description} />)
        }
    </div>
  )
}

export default Search