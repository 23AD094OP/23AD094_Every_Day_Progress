import React from 'react'
import "./index.css"

function View({title , description}) {

  return (
    <div id='view'>
      <h1 id='headt'>{title}</h1>
     <p id='des'>{description}</p>
    </div>
  )
}

export default View