const mongoose = require('mongoose')

async function db(){
    try{
    await mongoose.connect("mongodb://localhost:27017/course")
    console.log("Connected Database");
    
}catch(error){
    console.log("error ocurr in Database");
    
}
}

module.exports = db