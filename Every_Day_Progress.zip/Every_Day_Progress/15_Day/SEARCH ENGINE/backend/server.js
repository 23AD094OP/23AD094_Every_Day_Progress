const express = require('express')
const app = express()
const courseSchema = require("./model/schema.js")
const db = require('./db/db.js')
const cors = require('cors')

app.use(cors())

app.get("/api/v1/search",async (req , res) =>{
 await db()
//  let course =await courseSchema.find()
//  console.log(course);
let query = req.query.search
let course =await courseSchema.find({title:{$regex:query , $options:"i"}})
console.log(query);

console.log(course);


//  res.send("hello world!")
// res.send(course);
 res.json(course)
})

app.listen(4000 , ()=>{
    console.log("server running");
    
})